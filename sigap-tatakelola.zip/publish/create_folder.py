import os


# Using readlines()
file1 = open('./folder.txt', 'r')
Lines = file1.readlines()
  
count = 0
# Strips the newline character
for line in Lines:
    count += 1
    #print("Line{}: {}".format(count, line.strip()))
    #print(line.strip())
    path = './'+line.strip()
    print(count, path)
    isExist = os.path.exists(path)
    if not isExist:
        # Create a new directory because it does not exist 
        os.makedirs(path)
        print("The new directory is created ", path)
    else:
        print("The directory ", path, " is already exist")

file1.close()
'''
path = './API'

# Check whether the specified path exists or not
isExist = os.path.exists(path)

if not isExist:
  
  # Create a new directory because it does not exist 
  os.makedirs(path)
  print("The new directory is created ", path)
  '''