#!/bin/bash

TARGET=~/sigap_v2/data/produsen
PROCESSED=~/sigap_v2/data/produsen

inotifywait -r -m -e modify -e create -e moved_to --format "%w%f" $TARGET \
        | while read FILENAME
                do
                        echo Detected $FILENAME, syncronizing
                        scp "$FILENAME" sigap@172.16.3.163:"$FILENAME"
#                        mcli cp "$FILENAME" minio/upload/"$FILENAME"
                done
#        | while read FILENAME
#                do
#                        echo Detected $FILENAME, syncronizing
#                        sudo scp "$TARGET/$FILENAME" sigap@172.16.3.163:"$PROCESSED/$FILENAME"
#                done
